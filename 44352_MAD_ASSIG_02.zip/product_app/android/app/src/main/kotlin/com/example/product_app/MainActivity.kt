package com.example.product_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
